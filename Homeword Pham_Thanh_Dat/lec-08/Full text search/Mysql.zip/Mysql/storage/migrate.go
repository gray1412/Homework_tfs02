package storage

func Migrate() {
	CreateReview()
}
